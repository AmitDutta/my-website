package net;

public class Nframe 
{
        private String msg;
	private int index;
	private String dlName;
	private String port;
	
	public Nframe(String msg,int index,String dlName,String port)
	{
		this.msg=msg;
		this.index=index;
		this.dlName=dlName;
		this.port=port;	
	}
	
	public String getMessage()
	{
		return this.msg;
	}
	
	public int getIndex()
	{
		return this.index;
	}
	
	public String getdlName()
	{
		return this.dlName;
	}
	
	public String getPort()
	{
		return this.port;
	}

}
