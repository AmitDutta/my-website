package net;

public class bit
{
        int bitLength=8;
	
        public bit()
        {
            
        }
	        
        public String StringToBitString(String input)
	{
		StringBuffer buffer = new StringBuffer();
                   
                for (int i = 0; i < input.length(); i++)
                {
                    //buffer.append(Integer.toString(input.charAt(i), 2));
                    String temp=Integer.toString(input.charAt(i), 2);
                    if(temp.length()<this.bitLength)
                    {
                        int bitNeeded=this.bitLength-temp.length();
                        for(int j=1;j<=bitNeeded;j++)
                        {
                            temp="0"+temp;
                        }
                    }
                    buffer.append(temp);
                 }
        
                String bitString=buffer.toString();
                return bitString;
	}
	
	public String Encode(String s)
	{
		int i,count;
		count=0;
		StringBuffer res=new StringBuffer();
		//char []arr=s.toCharArray();
		
		for(i=0;i<s.length();i++)
		{
			if(count==5)
			{
                            res.append('0');	
                            count=0;
				
			}
			
			if(s.charAt(i)=='1')
			{
                            count++;
                            res.append(s.charAt(i));
				
			}
			else 
			{
                            count=0;
                            res.append(s.charAt(i));
			}
		}
		if(count==5)res.append('0'); //append zero at the end if five 1 at the end
                
            //if the decoded string's length is not a multiple of 7 add extra zero behind
            
            while ((res.length() % this.bitLength) != 0) {
                res.append('0');
            }
		//System.out.printf("Original String: %s Length %d\nStuffed String: %s Length %d\n",s,s.length(),res,res.length());
                return res.toString();
	}
        
        public String decode(String s)
        {
            int i,count;
	    count=0;
	    StringBuffer res=new StringBuffer();
	    //char []arr=s.toCharArray();
            
            for(i=0;i<s.length();i++)
            {
                if(count==5)
		{
                    count=0;
                    continue;
		}
			
		if(s.charAt(i)=='1')
		{
                    count++;
                    res.append(s.charAt(i));
		}
		else 
		{
                    count=0;
                    res.append(s.charAt(i));
		}
                
            }
            
            int total=res.length()-1;
            while((res.length()%this.bitLength)!=0)
            {
                res.deleteCharAt(total--);
            }
            
          //  System.out.printf("Decoded String: %s Length %d\n", res,res.length());
            return res.toString();
            
        }
        
        public String BitStringToString(String s)
        {
            StringBuffer buff=new StringBuffer();
            int i=0;
            int len=s.length();
            while(i<len)
            {
                
                String temp=s.substring(i, i+this.bitLength);
               // System.out.printf("%s\n",temp);
                
                int ans=Integer.parseInt(temp,2);
                
                buff.append((char)ans);
                //System.out.printf("%c",ans);
                i+=this.bitLength;
            }
            
            return buff.toString();
        }
	
}