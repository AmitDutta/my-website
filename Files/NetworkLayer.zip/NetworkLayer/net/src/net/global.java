package net;

import java.util.LinkedList;

public class global 
{    
    public static LinkedList nlBuffer=new LinkedList();

}
