package net;

import javax.comm.*;
import java.io.*;
import java.util.LinkedList;
import javax.swing.*;

public class dll implements Runnable,SerialPortEventListener
{
    
    public LinkedList msgBuffer;
    int index;
    
    public crc crctest;
    public bit stuff;
    public String portName;
    public String dlName;
    
    public boolean ACKreceived;
    static boolean DATAreceived;
    
    private int timeOut;
    
    //variable define by us
    public byte flag=0X7E;
    public byte sendSeqNo;
    public int receivSeqNo;
    /***
     *  variables for using comm port
     ***/
    public CommPortIdentifier portId;
    public SerialPort sPort;
    
    public InputStream is;
    public OutputStream os;
    public Thread sender;
    public Thread receiver;
    
        //ui elements
    private JTextArea jTextArea1;
    private JTextField jTextField1;
    
    public dll()
    {       
        JOptionPane.showMessageDialog(null, "I am new");
    }
    
    public dll(String dlName,String port,JTextArea jTextArea1,JTextField jTextField1) 
    {
    
        
        msgBuffer=new LinkedList();
        
        crctest=new crc();
        stuff=new bit();
        
        this.portName=port;
        this.dlName=dlName;//+">"+this.portName;
        this.jTextArea1=jTextArea1;
        this.jTextField1=jTextField1;
        
        //get the index
        
        this.index=Integer.parseInt(this.dlName.substring(2))-1; //as Name starts from 1 but indexing from 0
        
        //open ports and streams
        try 
        {
            portId = CommPortIdentifier.getPortIdentifier(portName);
            sPort = (SerialPort) portId.open("my port 1", 1);
            
            System.out.println(portName + " Successfully opened :-)");
            
            is = sPort.getInputStream();
            os = sPort.getOutputStream();
            
            //must add this two lines
            sPort.addEventListener(this);
            sPort.notifyOnDataAvailable(true);
        } 
        catch (Exception ex) 
        {
            JOptionPane.showMessageDialog(null,"at dll : "+this.dlName+"\n"+ex.toString());
            
        }
        
        //start dll
        //inititate seq numbers
        this.sendSeqNo=1;
	this.receivSeqNo=-1;
        
        //JOptionPane.showMessageDialog(null, this.dlName);
        
        sender = new Thread(this, "sender"+this.portName);
        receiver = new Thread(this, "receiver"+this.portName);
        sender.start();
        receiver.start();
        
    }
    
    public void run()
    {
        //System.out.println("this is a test");
        if(Thread.currentThread().getName().equals("sender"+this.portName))
        {
            while(true)
            {
                while(  this.msgBuffer.isEmpty() == true )    //btn1Clicked == false)
                {
                    try 
                    {
                        Thread.currentThread().sleep(100);
                    } 
                    catch (Exception ex) 
                    {
                        JOptionPane.showMessageDialog(null, "AT DLL Receiver Thread:" + ex.toString());
                    }
                }
                
                timeOut=0;
                //String msg = jTextField1.getText();
                String msg=(String)this.msgBuffer.removeFirst();
                //jButton1.setEnabled(false);
                //jTextField1.setText("");
                
                //sendFrame(msg);
                //this.ACKreceived = false;
                
                while(ACKreceived == false)
                {
                    
                    sendFrame(msg);
                    
                    
       //             jTextArea1.append("Main Message: " +msg+"\nSeq# "+sendSeqNo+"\n");

                    //for(int i=0; i<10 && ACKreceived == false; i++)
                    //{
                    int loop=0;
                    while( loop <10  && ACKreceived == false )
                    {
                        try
                        {
                            Thread.currentThread().sleep(500);
                        }
                        catch (Exception ex) 
                        {
                            JOptionPane.showMessageDialog(null,"While Receiver sleeping :"+ex.toString());
                        }
                        loop++;
          //              jTextArea1.setText(jTextArea1.getText()+ "..");
                    }
                    
                    if(ACKreceived == true)
                    {
                        //jTextArea1.append( "Frame Send and ACK received\n");
                        //jTextArea1.append("\n---------------------------------------\n");
                        break;
                    }
                    
                    else
                    {
                        timeOut++;
                        jTextArea1.append("at tmeout"+this.timeOut+"\n");
                        if(timeOut == 5) 
                        {
             //               jTextArea1.append("here+++\n");
                            break;
                        }
                    }
                }
                
              //  jButton1.setEnabled(true);                
//                btn1Clicked = false;
                ACKreceived = false;
            }            

        }
        else if(Thread.currentThread().getName().equals("receiver"+this.portName))  //receiver thread runs here
        {
//            System.out.println("Receiver thread created");
            
            while(true)
            {
                //while(DATAreceived == false)
               // {
                    try 
                    {
                        Thread.currentThread().sleep(100);
                    }
                    catch (Exception ex) 
                    {
                        JOptionPane.showMessageDialog(null,"While Receiver sleeping :"+ex.toString());
                    }
                //}
                
                //receiveFrame();

               // DATAreceived = false;
            }            
        }
        
    }
    
private void sendFrame(String msg)
{
    
    //find the crc of the message
    /**************/
    StringBuffer br=new StringBuffer();
    for (int i = 0; i < msg.length(); i++) 
    {
        br.append(Integer.toString(msg.charAt(i), 2));
    }
    
    String crc=crctest.calc(br,0);
    
    //now i have msg and crc
    String haveToStuff=stuff.StringToBitString(msg)+crc; //msg er bitString + crc er bitString
    
   // JOptionPane.showMessageDialog(null,/*stuff.StringToBitString(msg)+"--"+crc+"--"+*/haveToStuff+"-->"+haveToStuff.length());
    
    //padding extra 0
    
    //flip a bit before start
  /*  if(jRadioButton1.isSelected() == true)
    {
        StringBuffer err=new StringBuffer(haveToStuff);
        if(err.charAt(6)=='1') err.replace(6,7,"0"); //err.re
         else err.replace(6,7,"1");
      //  JOptionPane.showMessageDialog(null, haveToStuff+"-"+err.toString());
        haveToStuff=err.toString();
        jRadioButton1.setSelected(false);
                  
    }*/
    
    
    String stuffedString=stuff.Encode(haveToStuff);
    
   // JOptionPane.showMessageDialog(null,stuffedString+" "+stuffedString.length());
    
    //now i got a stuffed string 
    
    byte[] crcarr = crc.getBytes();
    //both crc and crcarr are of 32 length 
    //0-31 this length :-)
   // javax.swing.JOptionPane.showMessageDialog(null, crcarr.length + "--" + crc.length());
    /***************/
    byte []arr=stuffedString.getBytes();
    //byte []arr=msg.getBytes();
    //byte []toSend=new byte[arr.length+35];
    byte []toSend=new byte[arr.length+3];
    toSend[0]=this.flag;
			
  
    toSend[1]=this.sendSeqNo;
    
    System.arraycopy(arr, 0, toSend, 2, arr.length);//msg+crc is copied
    
    //int crcPosition=(2+arr.length);
    
    //System.arraycopy(crcarr, 0, toSend, crcPosition, crcarr.length);
    
    toSend[toSend.length - 1] = flag;

  //  JOptionPane.showMessageDialog(null, toSend.length);
  //  jTextArea1.append("\nSending::\n" + new String(toSend) + "\n");
   
  //  System.out.println("Sending" + new String(toSend) + "\n");
    
    
    try {
        //out.write(arr);
        //gb.globalMsg = toSend;
        os.write(toSend);
        //	msg1=new String(toSend);
        //gb.ack = false;
    //wait();
    } 
    catch (Exception ex) {
        System.out.println(ex.toString() + "\n");
        ex.printStackTrace();
    }
  
   /*if(this.errorMixed)
    {
        this.errorMixed=false;
        this.howManyerr++;
    }*/
    
}
    
private void receiveFrame() 
{
    int i = -100;
    try 
    {
        i = is.available();
    } 
    catch (Exception ex)
    {
        ex.printStackTrace();
    }


//    System.out.printf("%d\n", i);
    byte b[] = new byte[1000000];
    
    try {
        is.read(b);
    
    } 
    catch (Exception ex) 
    {
        ex.printStackTrace();
    }

    byte ack = 0xA;

    
    
    //msg validation 
    int counter=1;
    char flag1=(char)b[0];
    
    if(flag1=='~')
    {
        
        while((char)b[counter] != '~')//look for the end flag
        {
            counter++;
        }
            
    }
    
    else JOptionPane.showMessageDialog(null, "Received something without a starting flag :(");
    
    
    char flag2=(char)b[counter];
    counter++;//this is the length of the message
    //JOptionPane.showMessageDialog(null, counter);
    //JOptionPane.showMessageDialog(null, flag1+"--"+flag2+" "+b.length);
    
    //now copy the sq#
    int seq=(int)b[1];
    
    //jTextArea1.append("\nreceived:" + seq + "initial:" + receivSeqNo + "\n"); /******************/
//    System.out.println("received:" + seq + "initial:" + receivSeqNo + "\n");
    //JOptionPane.showMessageDialog(null, seq);
    /*
    for (int k = 0; k < i; k++) {
        buff.append((char) b[k]);
    }
    
    String receiv = new String(buff); */
    if (seq == receivSeqNo) 
    {
        jTextArea1.append("\nRepeated Message" + receivSeqNo+"\n");
        System.out.println("Repeat" + receivSeqNo);
        this.SendAck();
    }
    else 
    {

        if (seq == 4) //ack
        {
            ACKreceived = true;
    //        jTextArea1.append("\nACK received" + "-->Global ack:-->" + ACKreceived + "\n");
   //         System.out.print("ACK" + "global ack:-->" + ACKreceived + "\n");
            //System.out.print("at reciv"+gb.ack);
            //notifyAll();

            //received an ack.so change the seq #
            byte one = 1;
            byte zero = 0;


            sendSeqNo = sendSeqNo == 0 ? one : zero;
        } 
        else 
        {
            
            StringBuffer buff=new StringBuffer();
            for (int k = 2; k < (counter-1); k++)
            {
                buff.append((char) b[k]);
            }
            
            String haveToDecode=new String(buff);
            
            //remove bit stuffing
            String receiv=stuff.decode(haveToDecode);
            
            StringBuffer temp=new StringBuffer(receiv);
            //remove trailing zeros
            int len=temp.length()-1;
            while((temp.length() % stuff.bitLength) != 0)
            {
                temp.deleteCharAt(len--);
            }
            
            //update receiv
            receiv=new String(temp);
   //         jTextArea1.append("\n"+"Total msg after decode and padding:\n"+receiv+"\nLength:"+receiv.length());
            String msgGot=receiv.substring( 0,(receiv.length()-(32)) );
   //         jTextArea1.append("\nMessage (Binary): "+msgGot+"\n-->Message Length: "+msgGot.length());
            
            int marker=msgGot.length();
            msgGot=stuff.BitStringToString(msgGot);
   //         jTextArea1.append("\nMessage (String): "+msgGot);
            //JOptionPane.showMessageDialog(null,msgGot);
            String crc=receiv.substring(marker/*msgGot.length()*/);
     //       jTextArea1.append("\nCRC: "+crc+"\nCRC Length: "+crc.length());
            
            //my final strings are msgGot and crc
            
            //now crc checking
            StringBuffer crcTemp=new StringBuffer();
            for(int p=0;p<msgGot.length();p++)
            {
                crcTemp.append(Integer.toString(msgGot.charAt(p), 2));
            }
            String binary=crcTemp.toString();
            String check=binary+crc;
            String val=crctest.calc(new StringBuffer(check), 1);//correction mode
            //jTextArea1.append(val);
            int errHappened=0;
            if(val.equals("") || val.equals("0"))
            {
         //       jTextArea1.append("\nFCS Result :Matched");
                receivSeqNo = seq;
            }            
            else 
            {
           //     jTextArea1.append("\nFCS Result :Not matched.Not sending ACK");
                errHappened=1;
            } 
         
       //     jTextArea1.append("\n---------------------------------------\n");
            
            if( errHappened==0)
            {
                //global.nlBuffer.add(msgGot+">"+this.dlName);
                global.nlBuffer.add(new Nframe(msgGot,this.index, this.dlName, this.portName));
                this.SendAck();
            }
            
            //else don't send ack 
        }
    }
        	
}
   private void SendAck()
   {
        try 
        {
            OutputStream out = this.sPort.getOutputStream();
            String text = "ACK";

            //ACK frame
            byte[] st = new byte[text.length() + 3];
            st[0] = flag;
            st[1] = 4;
            System.arraycopy(text.getBytes(), 0, st, 2, text.length());
            st[st.length - 1] = flag;
            //
         //   System.out.println(new String(st));
            out.write(st);
        } 
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
    }
    
    public void serialEvent(SerialPortEvent serialPortEvent) 
    {
        if( serialPortEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE)  
        {
            receiveFrame();
        }
    }
    
}
