package net;
public class crc 
{
    public static String poly="111011011011100010000011001000001"; 
  // public String poly="110101";
    
    public crc()
    {
        
    }
   
   public char xor(char x,char y)
   {
       if(x == y) return '0';
       else if(  (x=='0' && y=='1') || (x=='1' && y=='0')    ) return '1';
       
       return '3';
       
   }
   public String calc(StringBuffer br,int mode)
   {
       //System.out.printf("tonmoy");
       int i,loop,flag;
       flag=loop=0;
       int val=poly.length()-1;
       if(mode ==0)
       {
           for(i=1;i<=val;i++) br.append('0');
       }
       int total=br.length();
       String temp="";
       StringBuffer res=new StringBuffer();
       StringBuffer remainder=new StringBuffer();
       
       //System.out.println(br);
       while(loop<br.length())
       {
           int end=1;
           if(flag == 0)
           {
               end=loop+val+1;
               if(end<br.length())
               {
                   temp=br.substring(loop,end);
                   loop=end-1;
                   flag=1;
               }
               
           }
           else 
           {
               temp=remainder.toString();
               remainder.delete(0, remainder.length());
               
           }
                //loop=end;
               // System.out.println("temp "+temp+" "+"loop "+loop+" "+" end"+end);
                
                for(int j=0;j<temp.length();j++)
                {
                    char ans=this.xor(temp.charAt(j), this.poly.charAt(j));
                    remainder.append(ans);
                }
                res.append('1');
                
                //remaove starting 0
                for(int j=0;j<remainder.length();j++)
                {
                    if(remainder.charAt(j)=='1') break;
                    else 
                    {
                        remainder.deleteCharAt(j);
                        j=j-1;
                    }
                }
                
               // System.out.println(remainder+" "+Integer.parseInt(remainder.toString()));
                //while(  Integer.parseInt(remainder.toString()) < Integer.parseInt(this.poly) )
                while(remainder.length() < this.poly.length())
                {
                    loop++;
                    if(loop>=br.length()) break;
                    remainder.append(br.charAt(loop));
                }
                
                //System.out.println("BR "+br+"-->"+"remainder "+remainder+"-->"+"loop "+loop);
           }
           //System.out.println("remainder "+remainder.toString());
           
           //format the string when mode 1
           /*
           if(mode == 1 && remainder.length() > 0)
           {
               if(Integer.parseInt(remainder.toString()) == 0) return "";
               //when 32 bit remainder then probs here as Integer.parseint
           }
           */
           
           //return for correction mode
           if(mode == 1 && remainder.length() >0)
           {
               
               for(i=0;i<remainder.length();i++)
               {
                   if(remainder.charAt(i) == '1') return remainder.toString();
               }
               
               if(remainder.length() == 0) return remainder.toString();
               else return "0";
           }
           //now this crc has length 0 for correction mode
           else if(mode == 1 && remainder.length() == 0 ) return remainder.toString();
           String crc=remainder.toString();
           while(crc.length() < 32)
            {
                 crc="0"+crc;
            }
           return crc;//remainder.toString();//remainder.toString();
           
           
       }
       

}
