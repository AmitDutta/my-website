package net;

import java.util.LinkedList;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;        

class node
{
    int v;
    int key;
    int pi;
    boolean marked;
}

public class calc
{
    int [][]w;
    int ver;
    public node []arr;
    node[]ans;
    int inf=3200;
    int nil=-1;
    StringBuffer path;
    
    public calc()
    {
        
    }
    
    public calc(int ver,int [][]graph)
    {
        this.ver=ver;
        this.w=graph;
        arr=new node[this.ver];
        ans=new node[this.ver];        
        for(int i=0;i<ver;i++)
        {
            arr[i]=new node();
            ans[i]=new node();
        }        
    }
    
    public node findMin()
    {
        int i;
        node temp=new node();
        temp.key=this.inf;
        temp.pi=-2;
        temp.v=-2;
        int indx=0;
        
        for(i=0;i<this.ver;i++)
        {
            if( (arr[i].key < temp.key) && arr[i].marked == false )
            {
                temp=arr[i];
                indx=i;
            }
        }
        
        arr[indx].marked=true;
        return temp;
    }
    
    public node[] process()
    {
        /**from constructor **/
        arr=new node[this.ver];
        ans=new node[this.ver];        
        for(int i=0;i<ver;i++)
        {
            arr[i]=new node();
            ans[i]=new node();
        }
        
        /******************/
        
        //init
        int i;
        for(i=0;i<this.ver;i++)
        {
            arr[i].v=i;
            arr[i].key=inf;
            arr[i].pi=nil;  
            arr[i].marked=false;
        }
        arr[0].key=0;
        
        //print();
        int cnt=0;
        
        int u;
        
        while(cnt<this.ver)
        {
            node min=this.findMin();
            //System.out.println(min.v+" "+min.key+" "+min.pi);
            u=min.v;
            
            ans[cnt].v=min.v;
            ans[cnt].key=min.key;
            ans[cnt].pi=min.pi;
            
            cnt++;
            
            for(i=0;i<this.ver;i++)
            {
                if( u >= 0/*u != -2*/ ) //to stop exception
                {
                    if(w[u][i] != 0)
                    {
                        //relax
                        if(arr[i].key > (arr[u].key + w[u][i]))
                        {
                            arr[i].key = arr[u].key + w[u][i];
                            arr[i].pi=u;
                        }
                    }
                }
                
            }            
            //mark this u so that it will not affect anymore            
        }
        
        /*
        for(i=0;i<this.ver;i++)
        {
            System.out.println("Vertex: "+ans[i].v+"->"+"Key :"+ans[i].key+"->"+"Pi :"+ans[i].pi);
        }
        */
        return ans;
        
    }
    
    public int FindIndx(int vertex)
    {
        int i;
        for(i=0;i<this.ver;i++)
        {
            if(ans[i].v == vertex) return i;
        }
            
        return nil;
    }
    public void FindPath(int src,int dest)
    {
       
        if(src == dest) System.out.print(src+" ");
        else if(ans[dest].pi == this.nil) System.out.println("No path exists");
        else 
        {
            if( this.FindIndx(dest) != nil ) //for thread exception
                FindPath(src,ans[this.FindIndx(dest)].pi);
            System.out.printf("%d ",dest);
        }
    }
    
    public String ShortestPathFinder(int src,int dest)
    {     
       
        if(src == dest) this.path.append(src);//System.out.print(src+" ");
        else if(ans[dest].pi == this.nil)
        {
            this.path.append("infinity");
            System.out.println("No path exists");
        }
        else 
        {
            if( this.FindIndx(dest) != nil )
            {
                ShortestPathFinder(src,ans[this.FindIndx(dest)].pi);
                path.append(dest);
            }
         //   System.out.printf("%d ",dest);
        }
        
        //System.out.println(path.toString());
      //  javax.swing.JOptionPane.showMessageDialog(null, path.toString());
        return path.toString();
    }
    
    public void print()
    {
        for(int i=0;i<this.ver;i++)
        {
            System.out.println(arr[i].v+"->"+arr[i].key+"->"+arr[i].pi);
        }
    }
    
    public void make(LinkedList lst)
    {
        int i,j,max;
        max=10;
        
        LinkedList index=new LinkedList();
        
        StringTokenizer tokens;
        
        int mat[][]=new int[max][max];
        
        
        //init
        for(i=0;i<max;i++)
        {
            for(j=0;j<max;j++)
            {
                mat[i][j] = 0;
            }
        }
        
        String str,str1,t1;
               
               
        for(i=0;i<lst.size();i++)
        {
            str=(String)lst.get(i);
            t1=str.substring(0,1)+i;//B1  //nodename+number
            index.add(t1);
        }
        
        
     /*   for(i=0;i<lst.size();i++)
        {
            System.out.println(index.get(i));
        }
         
        //see here */
        for(i=0;i<lst.size();i++)
        {
            str=((String)lst.get(i));
//            JOptionPane.showMessageDialog(null, str);
            str1=str.substring(1,str.indexOf(">"));
            tokens=new StringTokenizer(str1,"- "); //2 delims "-" and " "
            while(tokens.hasMoreTokens())
            {
                String test=tokens.nextToken();
                if(test.equals(" ") ) continue;
                j=this.SearchIndex(test, index);
                if( j != -1)  
                    mat[i][j]=Integer.parseInt(tokens.nextToken());
            }            
        }
        
       int total=i;
       
       /*******FIX ADJ MAT***/
       
       for(i=0;i<total;i++)
       {
           for(j=0;j<total;j++)
           {
                if(mat[i][j] >0 && mat[j][i] <= 0) mat[j][i]=mat[i][j];
                if(mat[i][j] <= 0 && mat[j][i] > 0) mat[i][j]=mat[j][i];
           }
       }
       /******/
       
       System.out.println("dumping adjacency matrix");
       for(i=0;i<total;i++)
        {
            for(j=0;j<total;j++)
            {
                System.out.print(mat[i][j]+ " ");
            }
                
            System.out.println();
        }
        this.ver=total;
        this.w=mat;
    }
    
    private int SearchIndex(String toFind,LinkedList lst)
    {
        int i,index;
        index=-1;
        String str;
        for(i=0;i<lst.size();i++)
        {
            str=(String)lst.get(i);
            if(str.substring(0,1).equalsIgnoreCase(toFind)) 
            {
                index=Integer.parseInt(str.substring(1));                        
            }
        }        
        return index; //if -1 then lst.size
    }
    
    public LinkedList shortest()
    {
        int i;
        LinkedList lst=new LinkedList();
        
        for(i=1;i<this.ver;i++)
        {
            path=new StringBuffer();
            String ans=this.ShortestPathFinder(0, i); //shortest path from 0 to all
            lst.add(ans);
        }
        
        return lst;        
    }
}
