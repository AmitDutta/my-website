package net;

import java.awt.Color;
import javax.swing.*;
import javax.comm.*;
import java.awt.event.*;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.Random;
import java.awt.Toolkit;

public class myFrame extends JFrame  implements Runnable
{
    static String name;
    
    static CommPortIdentifier portId;
    LinkedList ports;
    dll array[];
    static int MAX=10;
    
    Nframe msgGot;//messsage fromd dl
    
    javax.swing.Timer t;
    public static Random rnd;
    public static int lspCounter;
    
    public static String HELLO="HP";
    public static String HELLO_REPLY="HR";
    
    public static String ECHO="EP";
    public static String ECHO_REPLY="ER";

    public static String LSP_HEADER="LP";
    public static String MESSAGE_HEADER="M";
    
    public static LinkedList lspList;
    
    DefaultListModel dmHello;
    DefaultListModel dmEcho;
    
    /*graph relatef variables */
    //public static LinkedList shortestPath;//shortest path without COM and dl
    public static LinkedList shortest; //final shortest path with COM and dl
    public static DefaultListModel shortestPath;
    
    
    /*************************/
    @SuppressWarnings("empty-statement")
    public myFrame(String name) 
    {
        initComponents();
        
       // this.getContentPane().setBackground(Color.getHSBColor(1, 1,100));
       // this.jPanel1.setBackground(Color.LIGHT_GRAY);
       // this.setIconImage(Toolkit.getDefaultToolkit().getImage("chat_128x128_alpha.png"));
        
        //shortestPath=new LinkedList();
        shortestPath=new DefaultListModel();
        shortest=new LinkedList();
        //set the windows theme
        
        
        lspCounter=1;
        lspList=new LinkedList(); 
        rnd=new Random(500);
        
        dmHello=new DefaultListModel();
        dmEcho =new DefaultListModel();
     //   this.listHello.setModel(dmHello);
    //   this.listEcho.setModel(dmEcho);
        
        myFrame.name=name;
        lblName.setText(myFrame.name);
        //initiate dropdown
        Enumeration portList = CommPortIdentifier.getPortIdentifiers();;
        while(portList.hasMoreElements())
        {
            portId = (CommPortIdentifier) portList.nextElement();
            if(portId.getPortType() == CommPortIdentifier.PORT_SERIAL)
            {
                try
                {
                    cmboPorts.addItem(portId.getName());
                }
                catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(  null,"While listing COM ports"+ex.toString() );
                }
            }
        }
        
        array=new dll[MAX];        
        //array[1]=new dll();        
        //initialize lists
        this.ports=new LinkedList();        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cmboPorts = new javax.swing.JComboBox();
        btnStart = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btnSend = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        listHello = new javax.swing.JList();
        jScrollPane4 = new javax.swing.JScrollPane();
        listEcho = new javax.swing.JList();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnGraph = new javax.swing.JButton();
        btnPortAdd = new javax.swing.JButton();
        lblName = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Select Ports :");

        cmboPorts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmboPortsActionPerformed(evt);
            }
        });

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Functions"));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        btnSend.setText("Send");
        btnSend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jScrollPane3.setViewportView(listHello);

        jScrollPane4.setViewportView(listEcho);

        jTable1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Source", "Sequence", "Age", "Neighbours"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setToolTipText("LSP List");
        jTable1.setGridColor(new java.awt.Color(153, 204, 255));
        jScrollPane6.setViewportView(jTable1);

        btnGraph.setText("Graph");
        btnGraph.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGraphActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 537, Short.MAX_VALUE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 537, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSend)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                        .addComponent(btnGraph)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSend)
                            .addComponent(btnGraph))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE))
        );

        btnPortAdd.setText("Add Port");
        btnPortAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPortAddActionPerformed(evt);
            }
        });

        lblName.setText("jLabel2");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmboPorts, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7)
                        .addComponent(btnPortAdd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnStart)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 196, Short.MAX_VALUE)
                        .addComponent(lblName)
                        .addGap(35, 35, 35))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(cmboPorts, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnStart)
                        .addComponent(btnPortAdd))
                    .addComponent(lblName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        getAccessibleContext().setAccessibleName("window");

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void cmboPortsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmboPortsActionPerformed

   
}//GEN-LAST:event_cmboPortsActionPerformed

private void btnPortAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPortAddActionPerformed
    this.ports.add((String)this.cmboPorts.getSelectedItem());    
}//GEN-LAST:event_btnPortAddActionPerformed

private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        //first initiate dll    
    for(int i=0 ;i < this.ports.size();i++)
    {
        String dlName="dl"+(i+1);
        array[i]=new dll(dlName,(String)ports.get(i),this.jTextArea1,this.jTextField1);        
    }
    //start nl threads    
    new Thread(this,"msgHandler").start();
    new Thread(this,"ageHandler").start();
    new Thread(this,"graph").start();
    this.Time();
    
}//GEN-LAST:event_btnStartActionPerformed

private void btnSendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendActionPerformed
   
    //clear hello List
   
//    for(int i=0 ;i < this.ports.size();i++)
//    {
//        this.array[i].msgBuffer.add(myFrame.MESSAGE_HEADER+this.jTextField1.getText());
//    } 
    if(this.listEcho.getSelectedIndex() < 0) JOptionPane.showMessageDialog(this, "Select detination",myFrame.name+" Says..",2);
    else
    {
        String selected=(String)this.listEcho.getSelectedValue();
        String destination=selected.substring(selected.lastIndexOf("-")+1);
        
        //the message to Send
        
        String toSend=myFrame.MESSAGE_HEADER+myFrame.name+destination+this.jTextField1.getText();
        
        //get the neighbour on the destination
        int i1=selected.indexOf("-")+1; //first index of "-"
        String middle=selected.substring(i1,(i1+1));
        
                
        //getting the index of this destination
        boolean found=false;
        int index=-1;
        
        for(int i=0;i<this.dmEcho.size();i++)
        {
           String entry=(String)this.dmEcho.get(i); 
           if( entry.substring(0,1).equals(middle) )
           {
               found=true;
               index=Integer.parseInt( entry.substring(entry.indexOf("-")+1) );
               
               this.array[index].msgBuffer.add(toSend);
               this.listEcho.clearSelection();
               break;
               //JOptionPane.showMessageDialog(null, destination+" "+middle+" Index "+index,"Router Says..",2);
           }
        }
        if(found == false ) JOptionPane.showMessageDialog(null, "Not found in the echo List now","Router Says..",2);
    }
   
}//GEN-LAST:event_btnSendActionPerformed

private void btnGraphActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGraphActionPerformed
     this.graphControl();
}//GEN-LAST:event_btnGraphActionPerformed

    public void run()
    {
        if(Thread.currentThread().getName().equals("msgHandler"))
        {
            while(true)
            {   
                if (global.nlBuffer.isEmpty() == false) 
                {
                    msgGot = (Nframe) global.nlBuffer.removeFirst();
                    if( msgGot.getMessage().startsWith(myFrame.HELLO) )
                    {
                        String msg=myFrame.HELLO_REPLY+myFrame.name;
                        //JOptionPane.showMessageDialog(null, msgGot.getIndex());
                        array[msgGot.getIndex()].msgBuffer.add(msg); //send hello reply
                    }
                    else if( msgGot.getMessage().startsWith(myFrame.HELLO_REPLY) )
                    {
                        dmHello.addElement( msgGot.getMessage().substring(myFrame.HELLO_REPLY.length())+"-"+msgGot.getIndex() );//add,set are not working as they take object parameter
                    }
                    
                    else if( msgGot.getMessage().startsWith(myFrame.ECHO) )
                    {
                        String msg=myFrame.ECHO_REPLY+myFrame.name;
                        array[msgGot.getIndex()].msgBuffer.add(msg); //send echo reply
                    }
                    
                    else if( msgGot.getMessage().startsWith(myFrame.ECHO_REPLY) )
                    {
                        int hop=rnd.nextInt(10);                    
                        while(hop<=0) hop= rnd.nextInt(10);  
                        dmEcho.addElement(msgGot.getMessage().substring(myFrame.ECHO_REPLY.length())+" "+hop+"-"+msgGot.getIndex());
                    }
                    else if( msgGot.getMessage().startsWith(myFrame.LSP_HEADER) )
                    {
                        String lspToTest=msgGot.getMessage();
                        lspToTest=lspToTest.substring(myFrame.LSP_HEADER.length());
                        //this.jTextArea2.append(lspToTest);
                        int valid=this.Validity(lspToTest);
                        if(valid ==1) //if new then flood
                        {
                            //jTextArea2.setText("");
                            //jTextArea2.append("\nValid LSP packet: "+lspToTest+"\n");   
                            //while flooding send the original msg with lspcontrol
                            char lspSrc=lspToTest.charAt(0);
                            this.flood(msgGot.getMessage(),lspSrc);
                        }
                    }
                    
                    else //this is a Normal Message
                    {
                        String message=msgGot.getMessage();
                        String dest=message.substring(2,3);//header(0) source(1) dest(2)
                        if(dest.equals(this.name))
                        {
                            //this is my message
                            String mainMessage=msgGot.getMessage().substring(myFrame.MESSAGE_HEADER.length());
                            String source=mainMessage.substring(0,1);
                            String destination=mainMessage.substring(1,2);
                            String msg=mainMessage.substring(2);
                            String display="Source :"+source+"\n"+"Destination :"+destination+"\n"+"MSG+TraceROOT :"+msg+"\n";
                            this.jTextArea2.append(display);
                            //this.jTextArea2.append(msgGot.getMessage() +" "+msgGot.getdlName() +" "+msgGot.getIndex()+" "+msgGot.getPort()+"\n");
                            
                        }
                        else
                        {
                            String neighbour = null;
                            //find the shortest path from me to the dest
                            for(int i=0;i<myFrame.shortestPath.size();i++)
                            {
                                String entry=(String)myFrame.shortestPath.get(i);
                                String end=entry.substring(entry.lastIndexOf("-")+1);
                                if(dest.equals(end))
                                {
                                    //take the neighbour in this line
                                    int i1=entry.indexOf("-")+1;
                                    neighbour=entry.substring( i1, (i1+1) );
                                    break;
                                }
                            }
                            
                            if(neighbour != null)
                            {
                                for (int i = 0; i < this.dmEcho.size(); i++) 
                                {
                                    String entry = (String) this.dmEcho.get(i);
                                    if (entry.substring(0, 1).equals(neighbour)) 
                                    {
                                        //found = true;
                                        int index = Integer.parseInt(entry.substring(entry.indexOf("-") + 1));
                                        //this.array[index].msgBuffer.add(message);//without traceroot
                                        this.array[index].msgBuffer.add(message+myFrame.name);//with traceroot
                                        //this.listEcho.clearSelection();
                                        break;
                                    //JOptionPane.showMessageDialog(null, destination+" "+middle+" Index "+index,"Router Says..",2);
                                    }
                                }
                            }                            
                        }
                    }
                    
                    //if( /*msgGot.getMessage().startsWith(myFrame.LSP_HEADER)|| */ msgGot.getMessage().startsWith(myFrame.MESSAGE_HEADER) )
                    //this.jTextArea2.append(msgGot.getMessage() +" "+msgGot.getdlName() +" "+msgGot.getIndex()+" "+msgGot.getPort()+"\n");

                }

                try 
                {
                    Thread.sleep(100);
                } 
                catch (Exception ex) 
                {
                    ex.printStackTrace();
                }
            }
        }
        
         else if( Thread.currentThread().getName().equals("ageHandler") )
         {
             try 
             {
                 while (true) 
                 {
                     Thread.sleep(2 * 1000);
                     //System.out.println("At age Thread:" + myFrame.lspList.size());
                     //clear the table first
                     for (int i = 0; i < this.jTable1.getRowCount(); i++) 
                     {
                         this.jTable1.setValueAt(" ", i, 0);
                         this.jTable1.setValueAt(" ", i, 1);
                         this.jTable1.setValueAt(" ", i, 2);
                         this.jTable1.setValueAt(" ", i, 3);
                     }

                     if (myFrame.lspList.size() > 0) 
                     {
                         for (int i = 0; i < myFrame.lspList.size(); i++) 
                         {
                             String lsp = (String) myFrame.lspList.get(i);

                             int age = Integer.parseInt(lsp.substring(lsp.indexOf(">>") + 2));
                             if (age > 0) 
                             {
                                 age--;
                                 lsp = lsp.substring(0, lsp.indexOf(">>") + 2);
                                 lsp = lsp + age;//add new decremented age

                                // System.out.println(lsp + " " + i);

                                 //global.lspList.add(i, lsp);
                                 if (age > 0) {
                                     myFrame.lspList.set(i, lsp); //replace the ith lsp            

                                     //source
                                     this.jTable1.setValueAt("  "+lsp.charAt(0), i, 0);

                                     //sequence
                                     int indx1 = lsp.indexOf(">") + 1;
                                     int indx2 = lsp.indexOf(">>");
                                     this.jTable1.setValueAt("  "+lsp.substring(indx1, indx2), i, 1);

                                     //age
                                     this.jTable1.setValueAt("  "+age, i, 2);

                                     //neighbours
                                     int in1 = lsp.indexOf("-") + 1;
                                     int in2 = lsp.indexOf(">");
                                     this.jTable1.setValueAt("  "+lsp.substring(in1, in2), i, 3);
                                 }
                             }
                             if (age == 0) //not else if
                             {
                                 myFrame.lspList.remove(i);//not else if                            
                             }
                         }
                     }
                 }
             } 
             catch (Exception ex) 
             {
                 JOptionPane.showMessageDialog(null, "Exception at Age Config Thread" + ex.getMessage());
             }
         }
        
        else if( Thread.currentThread().getName().equals("graph") )
        {
            try 
            {
                while(true)
                {
                    if(myFrame.lspList.size() > 0)  
                    {
                        //System.out.println("AT GRAPH.."+lspList.size());
                        this.graphControl();
                    }
                    Thread.sleep(5000);
                }
            }
            catch (Exception ex) 
            {
                JOptionPane.showMessageDialog(null, "Exception at graph Thread" + ex.toString());
                ex.printStackTrace();
            }
        }
    }
    
    public void Time()
    {
        //1000 ms= 1s
        int delay = 20000;//60000;//60 s
	ActionListener taskPerformer = new ActionListener()
        {
            public void actionPerformed(ActionEvent evt) 
            {
                int i;
                //sending Hello
                dmHello.removeAllElements();
                String helloPacket=HELLO+name;
                for( i=0;i<ports.size();i++ )
                {
                    array[i].msgBuffer.add(helloPacket);
                }
                
                //sleep 
                try 
                {
                    Thread.currentThread().sleep(2000);//((long)global.rnd.nextInt(20));
                } 
                catch (Exception ex) 
                {
                }
                
                //sending echo
                dmEcho.removeAllElements();
                if(dmHello.isEmpty() == false)
                {
                    String EchoPacket=ECHO+name;
                    for(i=0;i<dmHello.size();i++)
                    {
                        String element=(String)dmHello.get(i);
                        int index= Integer.parseInt(element.substring(element.indexOf("-")+1)); //this is the neighbour
                        array[index].msgBuffer.add(EchoPacket);//send echo Packet
                    }
                }
                
                //sleep 
                try 
                {
                    Thread.currentThread().sleep(2000);//((long)global.rnd.nextInt(20));
                } 
                catch (Exception ex) 
                {
                }
                
                //sending LSP
                if(dmEcho.isEmpty() == false)
                {
                    for(i=0;i<dmEcho.size();i++)
                    {
                        String element=(String)dmEcho.get(i); 
                        int mark1=element.indexOf(" ")+1;
                        int mark2=element.indexOf("-");
                        int index= Integer.parseInt(element.substring(mark2+1));
                        int hop=Integer.parseInt(element.substring(mark1,mark2));
                        String lsp=encode();
                        if( !(lsp.equals("NOLSP")) )
                        {
                            int age=60-hop;
                            lsp+=age;
                            array[index].msgBuffer.add(lsp);
                        }                        
                    }
                    lspCounter++;
                }
            }
        };
        
        t=new javax.swing.Timer(delay,taskPerformer);
        t.start(); //start the timer
        
    }
    
    private String encode() 
    {
        int i;
        StringBuffer str = new StringBuffer();
    
        if (this.dmEcho.size() > 0) 
        {
            str.append(myFrame.LSP_HEADER+myFrame.name + "-");//lsp source name
            for (i = 0; i < this.dmEcho.size(); i++) 
            {
                String element= (String)this.dmEcho.get(i);
                element=element.substring(0, element.indexOf("-"));//remove the index field 
                
                if (i == (this.dmEcho.size() - 1)) 
                {
                    str.append(element/*(String) this.dmEcho.get(i)*/ + ">" + myFrame.lspCounter + ">>");
                }
                else 
                {
                    str.append(element/*(String) this.dmEcho.get(i)*/ + "-");
                }
            }
        //JOptionPane.showMessageDialog(null, str.toString());
        } 
        else 
        {
            return myFrame.LSP_HEADER+"NOLSP";
        }
        return str.toString();
    }
    
    public int Validity(String msg) //ai msg er charat0 te src ace
    {
        int i;
        int isValid = 0;
        int checked=0;
              
        int seq=Integer.parseInt(msg.substring( msg.indexOf(">") + 1,msg.indexOf(">>") )); //new seq #
       
        char src=msg.charAt(0);
        for (i = 0; i < myFrame.lspList.size(); i++)
        {
            String test = (String) myFrame.lspList.get(i);
            char listSrc = test.charAt(0);
        
            int val = Integer.parseInt(test.substring( test.indexOf(">") + 1 ,test.indexOf(">>") )); //previous seq #
    
            if (src == listSrc) 
            {
                checked=1;
                
                if(seq<=val)isValid=0;

                if(seq > val)
                {
                    if(src == myFrame.name.charAt(0))
                    {
                        
                    }
                    else 
                    {
                        myFrame.lspList.remove(i);
                        myFrame.lspList.add(msg);
                        isValid=1;
                        break;
                    }                    
                }
            }
        }

        if(checked == 0) //not in the list before
        {
            if(src == myFrame.name.charAt(0))
            {
                        
            }
            else 
            {
               isValid=1;
               myFrame.lspList.add(msg);
            }
        }
        return isValid;
    }
    
    public void flood(String msg,char src)
    {
        int i;
        String lsp=msg;        
        for(i=0;i<dmEcho.size();i++)
        {
            String str = (String) dmEcho.get(i);        
            if (src != str.charAt(0))//the neighbour who doesn't sent lsp
            {
                int mark1=str.indexOf(" ")+1;
                int mark2=str.indexOf("-");
                int index= Integer.parseInt(str.substring(mark2+1));
                int hop=Integer.parseInt(str.substring(mark1,mark2));
                int lspAge=Integer.parseInt( lsp.substring(lsp.indexOf(">>")+2) );           
                int newAge=lspAge-hop; //decrementin age field                        
                lsp=lsp.substring( 0,lsp.indexOf(">>")+2 );                
                lsp=lsp+newAge;
                array[index].msgBuffer.add(lsp);                
            }
        }
    }
    
    
    public String FindIndx(String st, LinkedList lst) 
    {
        int i;
        String temp;
        for (i = 0; i < lst.size(); i++) 
        {
            String t7 = (String) lst.get(i);
            temp = t7.substring(1, 2);

            //    String t7=st.substring(1,2);
            //  JOptionPane.showMessageDialog(null, "t7 "+t7+" st "+st);
            if (temp.equalsIgnoreCase(st)) 
            {
                return t7.substring(0, 1);
            }
        }
        return "";
    }

    public void graphControl() 
    {
        //clear old graph
        myFrame.shortestPath.clear();
        myFrame.shortest.clear();
        //this.jComboBox4.removeAllItems();

        LinkedList lst = new LinkedList();
        calc cl = new calc();

        String myLsp = this.encode();
        //emcode function will add the LP first.have to remove this for calculation
        myLsp=myLsp.substring(myFrame.LSP_HEADER.length());

        //JOptionPane.showMessageDialog(null, myLsp);
        int i, j;
        
        if (!(myLsp.equals("NOLSP"))  ) 
        {
            lst.add(myLsp); //first my LSP

            
            for (i = 0; i < myFrame.lspList.size(); i++) 
            {
                lst.add(myFrame.lspList.get(i)); //then all others
            //this.graphArea.append((String)global.lspList.get(i));

            }
            
//           for(i=0;i<lst.size();i++ ) this.jTextArea2.append(">>"+(String)lst.get(i)+"\n");
  //          this.jTextArea2.append("...\n");

            //lst has all lsp first entry is this lsp and then others
            cl.make(lst);
            cl.process();
            LinkedList ans = cl.shortest();

//            for (i = 0; i < ans.size(); i++) 
//            {
//                this.jTextArea2.append((String) ans.get(i) + "\n");
//            }

            LinkedList indx = new LinkedList();
            String str, temp, t6;


            for (i = 0; i < lst.size(); i++) 
            {
                str = (String) lst.get(i);

                temp = str.substring(0, 1) + i;
                //JOptionPane.showMessageDialog(null, temp);
                indx.add(temp);
            }
            
            String spath;
            for (i = 0; i < ans.size(); i++)
            {
                spath = "";
                str = (String) ans.get(i);
                for (j = 0; j < str.length(); j++) 
                {
                    temp = str.substring(j, j + 1);
                    //  JOptionPane.showMessageDialog(null, temp);
                    t6 = this.FindIndx(temp, indx);
                    if (j > 0) 
                    {
                        spath = spath + "-" + t6;
                    } else 
                    {
                        spath = spath + t6;
                    //JOptionPane.showMessageDialog(null, "spath "+spath);
                    }
                }
                myFrame.shortestPath.addElement(spath);
                
            //this.jComboBox4.addItem(spath);
            }
            this.listEcho.setModel(shortestPath);
        }
      //  else this.jTextArea2.append(myLsp);
//        for(i=0;i < myFrame.shortestPath.size();i++ ) this.jTextArea2.append((String)shortestPath.get(i)+"\n");
        
    }
    
    
    public static void main(String args[]) 
    {
        //set the theme first
        try 
        {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        //SwingUtilities.updateComponentTreeUI(this);
        }
        catch (Exception ex) 
        {
            System.out.println(ex.toString());
        }
           
        myFrame obj = new myFrame(JOptionPane.showInputDialog(null, "Network ID", "Welcome", 3));
        obj.setLocation(150, 150);
        //obj.setIconImage(Toolkit.getDefaultToolkit().getImage("chat_128x128_alpha.png"));
        obj.setVisible(true);
        obj.setTitle("Network ID: " + myFrame.name);
        obj.setResizable(false);
        obj.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGraph;
    private javax.swing.JButton btnPortAdd;
    private javax.swing.JButton btnSend;
    private javax.swing.JButton btnStart;
    private javax.swing.JComboBox cmboPorts;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lblName;
    private javax.swing.JList listEcho;
    private javax.swing.JList listHello;
    // End of variables declaration//GEN-END:variables

}
