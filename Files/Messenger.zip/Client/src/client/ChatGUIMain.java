package client;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
//import java.util.Scanner.*;
import java.util.Scanner;



public class ChatGUIMain extends JFrame implements ActionListener
{
  private JEditorPane   txtConversation = new JEditorPane();
  private JTextArea     txtSend = new JTextArea();
  private JButton       btnSend = new JButton("Send");
  private JList         lstUsers;
  private CChatListener listener;
  private JScrollPane   scrlConversation;
  private DefaultListModel lstUserList = new DefaultListModel();
	
  // Menu items
  private JMenuBar topMenu;
  private JMenu loginMenu, helpMenu,filemenu;
  private JMenuItem menuItemSettings, menuItemExit, menuItemAbout,menuitemfile;


   private final Color colorValues[] = 
      {Color.BLACK, Color.BLUE,Color.CYAN,Color.DARK_GRAY,Color.GRAY,Color.GREEN,Color.LIGHT_GRAY,Color.PINK,Color.MAGENTA,Color.ORANGE,Color.RED,Color.YELLOW,Color.WHITE};   
   // private final Color colorValues11[] = 
     // {Color.BLACK, Color.BLUE,Color.CYAN,Color.DARK_GRAY,Color.GRAY,Color.GREEN,Color.LIGHT_GRAY,Color.PINK,Color.MAGENTA,Color.ORANGE,Color.RED,Color.YELLOW,Color.WHITE};   
   
   private JRadioButtonMenuItem colorItems[],colorItems1[]; // color menu items
   private JRadioButtonMenuItem fonts[]; // font menu items
   private JCheckBoxMenuItem styleItems[]; // font style menu items
   //private JLabel displayJLabel; // displays sample text
   private ButtonGroup fontButtonGroup; // manages font menu items
   private ButtonGroup colorButtonGroup,colorButtonGroup1; // manages color menu items
   private int style; // used to create style for font

    private String messages = "";

  public ChatGUIMain(CChatListener l, String title)
  {
    super(title);

    listener = l;

    // Setup the controls
    controlsSetup();
    // Setup the menu
    menuSetup();
    pack();

    // Treat pressing the [x] as logging out
    this.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }

  private void controlsSetup()
  {
    // Create the conversation label
    JLabel lblConversation = new JLabel("Conversation:");

    // Create the conversation text area
    txtConversation.setEditable(false);
 
    txtConversation.setText("");
    // Create the conversation scroll pane
    scrlConversation = new JScrollPane(txtConversation);
    scrlConversation.setVerticalScrollBarPolicy(
      JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrlConversation.setPreferredSize(new Dimension(400,300));
    scrlConversation.setMinimumSize(new Dimension(10, 10));    

    // Create the lefttop pane
    JPanel lefttopPane = new JPanel();
    BoxLayout lefttopBox = new BoxLayout(lefttopPane, BoxLayout.Y_AXIS);
    lefttopPane.setLayout(lefttopBox);
    lefttopPane.add(lblConversation);
    lefttopPane.add(scrlConversation);

    // Create the send label
    JLabel lblSend = new JLabel("Send Message:");

    // Create the send text scroll pane and the send button
    JScrollPane scrlSend = new JScrollPane(txtSend);
    scrlSend.setVerticalScrollBarPolicy(
      JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrlSend.setPreferredSize(new Dimension(330, 30));
    scrlSend.setMinimumSize(new Dimension(10, 10));

    // Set the send button properties
    btnSend.setPreferredSize(new Dimension(70,30));
    btnSend.setMinimumSize(new Dimension(10, 10));
    btnSend.addActionListener(this);

    // Set the send pane
    JPanel sendPane = new JPanel();
    BoxLayout sendBox = new BoxLayout(sendPane, BoxLayout.X_AXIS);
    sendPane.setLayout(sendBox);
    sendPane.add(scrlSend);
    sendPane.add(btnSend);

    // Create the leftbottom pane
    JPanel leftbottomPane = new JPanel();
    BoxLayout leftBottomBox = new BoxLayout(leftbottomPane, BoxLayout.Y_AXIS);
    leftbottomPane.setLayout(leftBottomBox);
    leftbottomPane.add(lblSend);
    leftbottomPane.add(sendPane);

    // Create the left split pane
    JSplitPane leftSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                                          lefttopPane,
                                          leftbottomPane);
    leftSplitPane.setOneTouchExpandable(false);
    leftSplitPane.setDividerLocation(300);
    leftSplitPane.setPreferredSize(new Dimension(400, 400));

    // Create the list on the right hand side
    lstUsers = new JList(lstUserList);
    lstUsers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    JScrollPane scrlContacts = new JScrollPane(lstUsers);
    scrlContacts.setVerticalScrollBarPolicy(
      JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrlContacts.setHorizontalScrollBarPolicy(
      JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    scrlContacts.setPreferredSize(new Dimension(150, 400));
    scrlContacts.setMinimumSize(new Dimension(10, 10));

    // Create a split pane between the conversation and the list
    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                                          leftSplitPane,
                                          scrlContacts);
    splitPane.setOneTouchExpandable(true);
    splitPane.setDividerLocation(400);
    splitPane.setPreferredSize(new Dimension(550, 400));

    setContentPane(splitPane);

    // Setup a mouse listener to trap double clicks
    // on a list item
    MouseListener mouseListener = new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
          int index = lstUsers.locationToIndex(e.getPoint());
          listener.onInitiatePrivateMessage((String)lstUserList.get(index));
        }
      }
   };
   lstUsers.addMouseListener(mouseListener);

  }

  public void menuSetup()
  {
    topMenu = new JMenuBar();
    setJMenuBar(topMenu);
    loginMenu = new JMenu("Login");
    //menuItemLogin = new JMenuItem("Change user");
   // loginMenu.add(menuItemLogin);
    menuItemExit = new JMenuItem("Exit");
    loginMenu.add(menuItemExit);
    //menuItemLogin.addActionListener(this);
    menuItemExit.addActionListener(this);
    topMenu.add(loginMenu);
    helpMenu = new JMenu("Help");
    menuItemAbout = new JMenuItem("About...");
    menuItemAbout.addActionListener(this);
    helpMenu.add(menuItemAbout);
    topMenu.add(helpMenu);
    
    
    
    
     //file ar jonno kortasi/////////////////
    filemenu=new JMenu("File");
    menuitemfile =new JMenuItem("File");
    menuitemfile.addActionListener(this);
    filemenu.add( menuitemfile);
    topMenu.add(filemenu);
    
    
    
    
    
     //bar = new JMenuBar(); // create menu bar
      //setJMenuBar( bar ); // add menu bar to application
      //bar.add( fileMenu ); // add file menu to menu bar
	
	  JMenu formatMenu = new JMenu( "Format" ); // create format menu
      formatMenu.setMnemonic( 'r' ); // set mnemonic to r

      // array listing string colors
      String colors[] = {"Black","BLUE","CYAN","DARK_GRAY","GRAY","GREEN","LIGHT_GRAY","PINK","MAGENTA","ORANGE","RED","YELLOW ","White"};

      JMenu colorMenu = new JMenu( "Color" ); // create color menu
      colorMenu.setMnemonic( 'C' ); // set mnemonic to C

      // create radiobutton menu items for colors
      colorItems = new JRadioButtonMenuItem[ colors.length ];
      colorButtonGroup = new ButtonGroup(); // manages colors
      ItemHandler itemHandler = new ItemHandler(); // handler for colors

      // create color radio button menu items
      for ( int count = 0; count < colors.length; count++ ) 
      {
         colorItems[ count ] = 
            new JRadioButtonMenuItem( colors[ count ] ); // create item
         colorMenu.add( colorItems[ count ] ); // add item to color menu
         colorButtonGroup.add( colorItems[ count ] ); // add to group
         colorItems[ count ].addActionListener( itemHandler );
      } // end for

      colorItems[ 0 ].setSelected( true ); // select first Color item

      formatMenu.add( colorMenu ); // add color menu to format menu
      formatMenu.addSeparator(); // add separator in menu

      // array listing font names
      String fontNames[] = { "Arial","Arial Black","Arial Narrow","Book antiqua","Bookman OldStyle","Century Gothic","Comic Sans MS","Franklin Gothic Mesium","Monospaced","Serif", "SansSerif","Tahoma"};
      JMenu fontMenu = new JMenu( "Font" ); // create font menu
      fontMenu.setMnemonic( 'n' ); // set mnemonic to n

      // create radiobutton menu items for font names
      fonts = new JRadioButtonMenuItem[ fontNames.length ];
      fontButtonGroup = new ButtonGroup(); // manages font names

      // create Font radio button menu items
      for ( int count = 0; count < fonts.length; count++ ) 
      {
         fonts[ count ] = new JRadioButtonMenuItem( fontNames[ count ] );
         fontMenu.add( fonts[ count ] ); // add font to font menu
         fontButtonGroup.add( fonts[ count ] ); // add to button group
         fonts[ count ].addActionListener( itemHandler ); // add handler
      } // end for

      fonts[ 0 ].setSelected( true ); // select first Font menu item
      fontMenu.addSeparator(); // add separator bar to font menu

      String styleNames[] = {"Bold", "Italic" }; // names of styles
      styleItems = new JCheckBoxMenuItem[ styleNames.length ];
      StyleHandler styleHandler = new StyleHandler(); // style handler

      // create style checkbox menu items
      for ( int count = 0; count < styleNames.length; count++ ) 
      {
         styleItems[ count ] = 
            new JCheckBoxMenuItem( styleNames[ count ] ); // for style
         fontMenu.add( styleItems[ count ] ); // add to font menu
         styleItems[ count ].addItemListener( styleHandler ); // handler
      } // end for

      formatMenu.add( fontMenu ); // add Font menu to Format menu
      topMenu.add( formatMenu ); // add Format menu to menu bar
      
       JMenu backgroundMenu = new JMenu( "background" );
       backgroundMenu.setMnemonic( 'b' );
       String colors1[] = {"Black","BLUE","CYAN","DARK_GRAY","GRAY","GREEN","LIGHT_GRAY","PINK","MAGENTA","ORANGE","RED","YELLOW ","White"};

       JMenu colorMenu1 = new JMenu( "Color" ); // create color menu
       colorMenu1.setMnemonic( 'C' ); // set mnemonic to C

      
      colorItems1 = new JRadioButtonMenuItem[ colors1.length ];
      colorButtonGroup1 = new ButtonGroup(); // manages colors
      ItemHandler mtemHandler = new ItemHandler(); // handler for colors

      // create color radio button menu items
      for ( int count = 0; count < colors1.length; count++ ) 
      {
         colorItems1[ count ] = 
            new JRadioButtonMenuItem( colors1[ count ] ); // create item
         colorMenu1.add( colorItems1[ count ] ); // add item to color menu
         colorButtonGroup1.add( colorItems1[ count ] ); // add to group
         colorItems1[ count ].addActionListener( mtemHandler );
      } // end for

      //colorItems1[ 0 ].setSelected( true ); // select first Color item
	backgroundMenu.add(colorMenu1);	 
	   topMenu.add(backgroundMenu);
      
         
  }
  
  

  
  	private File getFile()
   {
      // display file dialog, so user can choose file to open
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setFileSelectionMode(
         JFileChooser.FILES_AND_DIRECTORIES );

      int result = fileChooser.showOpenDialog( this );

      // if user clicked Cancel button on dialog, return
      if ( result == JFileChooser.CANCEL_OPTION )
         System.exit( 1 );

      File fileName = fileChooser.getSelectedFile(); // get selected file

      // display error if invalid
      if ( ( fileName == null ) || ( fileName.getName().equals( "" ) ) )
      {
         JOptionPane.showMessageDialog( this, "Invalid File Name",
            "Invalid File Name", JOptionPane.ERROR_MESSAGE );
         System.exit( 1 );
      } // end if

      return fileName;
   } // end method getFile
	
  
  
  
  
  
  

  public void actionPerformed(ActionEvent e)
  {
    if(e.getSource() == btnSend)
    {
      // Replace all new lines with <br> tags when we send the data
      listener.onSendMessageToAll(txtSend.getText().replaceAll("\n", "<br>"));
      txtSend.setText("");
    }
    if(e.getSource() == menuItemExit)
    {
      System.exit(0);
    }
    if(e.getSource() == menuItemAbout)
    {
      JOptionPane.showMessageDialog(null, "Created by Tonmoy(0405072) & Amit(0405071)", "Buet Messenger", JOptionPane.INFORMATION_MESSAGE);
    }
    
    
     if(e.getSource() == menuitemfile)//trying 
   {
   	try
   	{
   		filetransfer();
   	}catch(IOException r1)
   	{
   		
   	}
   	   
   	   
   	 //FileInputStream fin=new FileInputStream(getFile());
   	  //nputStreamReader in=new  InputStreamReader(fin.read());
   	 //    listener.onSendMessageToAll(new InputStreamReader(File InputStream(getFile())));
   	     
   	     
   	
  /* 	int i,j=0;
   // 	String s;
   	char ch;
   	char array[]=new char[1100];
    FileInputStream fin;
    FileInputStream fout;

    try {
      fin = new FileInputStream("c:\\New.txt");
    } catch(FileNotFoundException e1) {
    	System.out.println("File Not Found");
      return;
    	
      
    } catch(ArrayIndexOutOfBoundsException e2) {
      System.out.println("Usage: ShowFile File");
      return;
    }

    // read characters until EOF is encountered
    do {
      i = fin.read();
      ch=(char)i;
      array[j]=ch;
      j++;
      
      //i++;
      //if(i != -1) System.out.write((char) i);
     // txtSend.setText(s);
      
          
    } while(i != -1);
    String s=new String(array);*/
    
    
    

  //  fin.close();
   	    
   	     
   	     
   	     
   	     
   	     
   	     
   	     
   	     
   	/*fin = new FileInputStream();
    r=new ObjectOutputStream();//(FileInputStream(getFile())));
    txtSend.setText(r.writeObject(fin.read(getFile())));*/

 /*	FileInputStream fin;
    	try
    	{
    		fin = new FileInputStream(getFile()); 
    		int i;
    	//	fin.read
    		
    		
    	//	txtSend.setText(fin.read(getFile()));
    	}/*catch(FileNotFoundException b) {
      System.out.println("File Not Found");
      return;
    } catch(ArrayIndexOutOfBoundsException b) {
      System.out.println("Usage: ShowFile File");
      return;
    }
  
  try
   {   int i=0; 	   
   	   while( i != -1);
   	   {
   	         i = fin.read();
             if(i != -1) txtSend.setText((char) i);
      }
   }  catch( IOException a){};
		
    	
    	
    	
    	//
  /* 	FileInputStream fis=new FileInputStream();
		//	fis.read(getFile()) ;
			txtSend.setText(fis.read(getFile()));
    	
      // Disconnect and show the login menu again*/
    }
 
   
  }
  
  
  public  void filetransfer() throws IOException
  {
  	  	int i,j=0,k=0,m=0;
   // 	String s;
   	char ch,newchar;
   	char array[]=new char[1000];
 //  	StringBuffer st;
    FileInputStream fin;
    FileInputStream fout;
    Scanner input;
    
//    String s=getFile();

    try {
     // fin = new FileInputStream("c:\\New.txt");
      fin = new FileInputStream(getFile());
    } catch(FileNotFoundException e1) {
    	System.out.println("File Not Found");
      return;
    	
      
    } catch(ArrayIndexOutOfBoundsException e2) {
      System.out.println("Usage: ShowFile File");
      return;
    }

    // read characters until EOF is encountered
    do {
      i = fin.read();
      ch=(char)i;
     // newchar=ch;
      
      array[j]=ch;
      j++;
     // String s=newchar;
      //i++;
      //if(i != -1) System.out.write((char) i);
     // txtSend.setText(s);
      
          
    } while(i != -1);
    //i=0;*/
     m=j+1;
     char  array1[]=new char[m];
     for(int n=0;n<=m;n++)
     {
     	array1[n]=array[n];
     }
     
    
    String s=new String(array1);
    
    
  /* input=new Scanner(new File("c:\\New.txt"));
   int l;
   try
   {
     	 while (input.hasNext())
   			{
   				l=input.nextInt();
   				j++;
   			}
   }catch(Exception e){}*/		      
    
    
    
  /*  char  array[]=new char[j+1];
    
  //  String s=new String(array);
    
    
  /*  //recent
    
     try {
     // fin = new FileInputStream("c:\\New.txt");
      fin = new FileInputStream(getFile());
    } catch(FileNotFoundException e1) {
    	System.out.println("File Not Found");
      return;
    	
      
    } catch(ArrayIndexOutOfBoundsException e2) {
      System.out.println("Usage: ShowFile File");
      return;
    }
    
    
       
    
    do {
      i= fin.read();
      ch=(char)i;
      array[k]=ch;
      k++;
      
      //i++;
      //if(i != -1) System.out.write((char) i);
     // txtSend.setText(s);
      
          
    } while(i != -1);
    
    
          
    String s=new String(array);
   
       listener.onSendMessageToAll(txtSend.getText().replaceAll("\n", "<br>"));
      txtSend.setText("");*/
     
     txtSend.setText(s);
     listener.onSendMessageToAll(txtSend.getText());
   //   listener.onSendMessageToAll()
    
    

  //  fin.close();
   	    
   	     
  }
  

 	
  
	 private class ItemHandler implements ActionListener 
   {
      // process color and font selections
      public void actionPerformed( ActionEvent event )
      {
         // process color selection
         for ( int count = 0; count < colorItems.length; count++ )
         {
            if ( colorItems[ count ].isSelected() ) 
            {
               txtSend.setForeground( colorValues[ count ] );
			   txtConversation.setForeground( colorValues[ count ] );	        
               break;
            } // end if
         } // end for
          for ( int count = 0; count < colorItems1.length; count++ )
         {
            if ( colorItems1[ count ].isSelected() ) 
            {
               txtSend.setBackground( colorValues[ count ] );
			   txtConversation.setBackground( colorValues[ count ] );	        
               break;
            } // end if
         } // end for

         // process font selection
         for ( int count = 0; count < fonts.length; count++ )
         {
            if ( event.getSource() == fonts[ count ] ) 
            {
               txtSend.setFont( 
                  new Font( fonts[ count ].getText(), style, 14 ) );
                  txtConversation.setFont( 
                  new Font( fonts[ count ].getText(), style, 14 ) );
            } // end if
         } // end for

         repaint(); // redraw application
      } // end method actionPerformed
   } // end class ItemHandler

   // inner class to handle item events from check box menu items
   private class StyleHandler implements ItemListener 
   {
      // process font style selections
      public void itemStateChanged( ItemEvent e )
      {
         style = 0; // initialize style

         // check for bold selection
         if ( styleItems[ 0 ].isSelected() )
            style += Font.BOLD; // add bold to style

         // check for italic selection
         if ( styleItems[ 1 ].isSelected() )
            style += Font.ITALIC; // add italic to style

         txtSend.setFont( 
            new Font( txtSend.getFont().getName(), style, 14 ) );
          txtConversation.setFont( 
            new Font( txtConversation.getFont().getName(), style, 14 ) );
         repaint(); // redraw application
      } // end method itemStateChanged
   } // end class StyleHandler   


//add finish


  public void showChat()
  {
    // Clear the list and reset the message header
    lstUserList.clear();
    messages = "";
//    txtConversation.setText(messageHeader + messageFooter);
    txtSend.setText("");

    setVisible(true);
  }

  public void messageReceived(String from, String message)
  {
   addMessage('\n' + from + "-->"+  message  );
  }

  private void addMessage(String message)
  {
    messages += message;
    txtConversation.setText(messages);
    txtConversation.selectAll();
    txtConversation.setCaretPosition(txtConversation.getSelectedText().length());
  }

  public void userJoined(String username)
  {
    lstUserList.addElement(username);
   addMessage("\n" + "User " + username + " has joined!!!");
  }

  public void userLeft(String username)
  {
    for(int i = 0; i < lstUserList.getSize(); i++)
    {
      if(((String)lstUserList.get(i)).equalsIgnoreCase(username))
      {
        lstUserList.remove(i);
        break;
      }
    }
   addMessage( "\n"+"User " + username + " has left!!!");
  }
}