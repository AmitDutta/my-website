package client;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class PrivateMessageNew extends JFrame implements ActionListener
{
	
	
	
	private JEditorPane   txtConversation = new JEditorPane();
  private JTextArea     txtSend = new JTextArea();
  private JButton       btnSend = new JButton("Send");
  private CPrivateMessageListener listener;
  private JScrollPane   scrlConversation;
  public  String localUsername;
  public  String remoteUsername;
  
   private JMenuBar bar;
  
  
   private final Color colorValues[] = 
      {Color.BLACK, Color.BLUE,Color.CYAN,Color.DARK_GRAY,Color.GRAY,Color.GREEN,Color.LIGHT_GRAY,Color.PINK,Color.MAGENTA,Color.ORANGE,Color.RED,Color.YELLOW,Color.WHITE};   
   private JRadioButtonMenuItem colorItems[]; // color menu items
   private JRadioButtonMenuItem fonts[]; // font menu items
   private JCheckBoxMenuItem styleItems[]; // font style menu items
   //private JLabel displayJLabel; // displays sample text
   private ButtonGroup fontButtonGroup; // manages font menu items
   private ButtonGroup colorButtonGroup; // manages color menu items
   private int style; // used to create style for font


  // Message Data items
  private String messageHeader ="";
  private String messageFooter = "";

  public PrivateMessageNew (CPrivateMessageListener l, String title, String localUser, String remoteUser)
  {
    super(title);

    listener = l;
    localUsername = localUser;
    remoteUsername = remoteUser;

    // Setup the controls
    controlsSetup();
    menuSetup();
    pack();

    // Catch pressing the [x] and call the close event
    this.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        listener.onClosePrivateMessage(remoteUsername);
      }
    });

    setVisible(true);
  }

  private void controlsSetup()
  {
    // Create the conversation label
    JLabel lblConversation = new JLabel("Conversation(Private):");

    // Create the conversation text area
    txtConversation.setEditable(false);
   // txtConversation.setContentType("text/html");
    txtConversation.setText("");
    // Create the conversation scroll pane
    scrlConversation = new JScrollPane(txtConversation);
    scrlConversation.setVerticalScrollBarPolicy(
      JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrlConversation.setPreferredSize(new Dimension(400,300));
    scrlConversation.setMinimumSize(new Dimension(10, 10));    

    // Create the lefttop pane
    JPanel lefttopPane = new JPanel();
    BoxLayout lefttopBox = new BoxLayout(lefttopPane, BoxLayout.Y_AXIS);
    lefttopPane.setLayout(lefttopBox);
    lefttopPane.add(lblConversation);
    lefttopPane.add(scrlConversation);

    // Create the send label
    JLabel lblSend = new JLabel("Send Message:");

    // Create the send text scroll pane and the send button
    JScrollPane scrlSend = new JScrollPane(txtSend);
    scrlSend.setVerticalScrollBarPolicy(
      JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrlSend.setPreferredSize(new Dimension(330, 30));
    scrlSend.setMinimumSize(new Dimension(10, 10));

    // Set the send button properties
    btnSend.setPreferredSize(new Dimension(70,30));
    btnSend.setMinimumSize(new Dimension(10, 10));
    btnSend.addActionListener(this);

    // Set the send pane
    JPanel sendPane = new JPanel();
    BoxLayout sendBox = new BoxLayout(sendPane, BoxLayout.X_AXIS);
    sendPane.setLayout(sendBox);
    sendPane.add(scrlSend);
    sendPane.add(btnSend);

    // Create the leftbottom pane
    JPanel leftbottomPane = new JPanel();
    BoxLayout leftBottomBox = new BoxLayout(leftbottomPane, BoxLayout.Y_AXIS);
    leftbottomPane.setLayout(leftBottomBox);
    leftbottomPane.add(lblSend);
    leftbottomPane.add(sendPane);

    // Create the left split pane
    JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                                          lefttopPane,
                                          leftbottomPane);
    splitPane.setOneTouchExpandable(false);
    splitPane.setDividerLocation(300);
    splitPane.setPreferredSize(new Dimension(400, 400));

    setContentPane(splitPane);
  }
  
  
  public void menuSetup()
  {
  	 bar = new JMenuBar(); // create menu bar
      setJMenuBar( bar ); // add menu bar to application
    //  bar.add( fileMenu ); // add file menu to menu bar

      JMenu formatMenu = new JMenu( "Format" ); // create format menu
      formatMenu.setMnemonic( 'r' ); // set mnemonic to r

      // array listing string colors
    //  String colors[] = { "Black", "Blue", "Red", "Green" };
		String colors[] = {"Black","BLUE","CYAN","DARK_GRAY","GRAY","GREEN","LIGHT_GRAY","PINK","MAGENTA","ORANGE","RED","YELLOW ","White"};

      JMenu colorMenu = new JMenu( "Color" ); // create color menu
      colorMenu.setMnemonic( 'C' ); // set mnemonic to C

      // create radiobutton menu items for colors
      colorItems = new JRadioButtonMenuItem[ colors.length ];
      colorButtonGroup = new ButtonGroup(); // manages colors
      ItemHandler itemHandler = new ItemHandler(); // handler for colors

      // create color radio button menu items
      for ( int count = 0; count < colors.length; count++ ) 
      {
         colorItems[ count ] = 
            new JRadioButtonMenuItem( colors[ count ] ); // create item
         colorMenu.add( colorItems[ count ] ); // add item to color menu
         colorButtonGroup.add( colorItems[ count ] ); // add to group
         colorItems[ count ].addActionListener( itemHandler );
      } // end for

      colorItems[ 0 ].setSelected( true ); // select first Color item

      formatMenu.add( colorMenu ); // add color menu to format menu
      formatMenu.addSeparator(); // add separator in menu

      // array listing font names
      //String fontNames[] = { "Serif", "Monospaced", "SansSerif" };
      String fontNames[] = { "Arial Narrow","Book antiqua","Serif", "Monospaced", "SansSerif","Bookman Old Style","Comic Sans MS","Tunga","Tahoma"};
      JMenu fontMenu = new JMenu( "Font" ); // create font menu
      fontMenu.setMnemonic( 'n' ); // set mnemonic to n

      // create radiobutton menu items for font names
      fonts = new JRadioButtonMenuItem[ fontNames.length ];
      fontButtonGroup = new ButtonGroup(); // manages font names

      // create Font radio button menu items
      for ( int count = 0; count < fonts.length; count++ ) 
      {
         fonts[ count ] = new JRadioButtonMenuItem( fontNames[ count ] );
         fontMenu.add( fonts[ count ] ); // add font to font menu
         fontButtonGroup.add( fonts[ count ] ); // add to button group
         fonts[ count ].addActionListener( itemHandler ); // add handler
      } // end for

      fonts[ 0 ].setSelected( true ); // select first Font menu item
      fontMenu.addSeparator(); // add separator bar to font menu

      String styleNames[] = { "Bold", "Italic" }; // names of styles
      styleItems = new JCheckBoxMenuItem[ styleNames.length ];
      StyleHandler styleHandler = new StyleHandler(); // style handler

      // create style checkbox menu items
      for ( int count = 0; count < styleNames.length; count++ ) 
      {
         styleItems[ count ] = 
            new JCheckBoxMenuItem( styleNames[ count ] ); // for style
         fontMenu.add( styleItems[ count ] ); // add to font menu
         styleItems[ count ].addItemListener( styleHandler ); // handler
      } // end for

      formatMenu.add( fontMenu ); // add Font menu to Format menu
      bar.add( formatMenu ); // add Format menu to menu bar
     
  }

  public void actionPerformed(ActionEvent e)
  {
    if(e.getSource() == btnSend)
    {
      String message = txtSend.getText().replaceAll("\n", "<br>");//aita rakte hobe
      // Replace all new lines with <br> tags when we send the data
      listener.onSendMessage(remoteUsername, message);
      // Add the local message to the conversation window
      addMessage("\n" + localUsername + "->>" + message + "\n");
  
      txtSend.setText("");
    }
  }
  
  
  	 private class ItemHandler implements ActionListener 
   {
      // process color and font selections
      public void actionPerformed( ActionEvent event )
      {
         // process color selection
         for ( int count = 0; count < colorItems.length; count++ )
         {
            if ( colorItems[ count ].isSelected() ) 
            {
               txtSend.setForeground( colorValues[ count ] );
			   txtConversation.setForeground( colorValues[ count ] );	        
               break;
            } // end if
         } // end for

         // process font selection
         for ( int count = 0; count < fonts.length; count++ )
         {
            if ( event.getSource() == fonts[ count ] ) 
            {
               txtSend.setFont( 
                  new Font( fonts[ count ].getText(), style, 14 ) );
                  txtConversation.setFont( 
                  new Font( fonts[ count ].getText(), style, 14 ) );
            } // end if
         } // end for

         repaint(); // redraw application
      } // end method actionPerformed
   } // end class ItemHandler

   // inner class to handle item events from check box menu items
   private class StyleHandler implements ItemListener 
   {
      // process font style selections
      public void itemStateChanged( ItemEvent e )
      {
         style = 0; // initialize style

         // check for bold selection
         if ( styleItems[ 0 ].isSelected() )
            style += Font.BOLD; // add bold to style

         // check for italic selection
         if ( styleItems[ 1 ].isSelected() )
            style += Font.ITALIC; // add italic to style

         txtSend.setFont( 
            new Font( txtSend.getFont().getName(), style, 14 ) );
          txtConversation.setFont( 
            new Font( txtConversation.getFont().getName(), style, 14 ) );
         repaint(); // redraw application
      } // end method itemStateChanged
   } // end class StyleHandler   



  public void messageReceived(String message)
  {
    addMessage("\n" + remoteUsername + "->>" + message + "\n");
  }

  public void userLeft()
  {
    addMessage("\n" + remoteUsername + " has disconnected!!!!");
    // Disable the send button
    btnSend.setEnabled(false);
  }

  private void addMessage(String message)
  {
    messageHeader += message;
    txtConversation.setText(messageHeader + messageFooter);

    txtConversation.selectAll();
    txtConversation.setCaretPosition(txtConversation.getSelectedText().length());
  }

  
}