package client;
import java.io.*;
//Ctansport a use kortasiiiiiiii

class ReadFromServer extends Thread
{
  private BufferedReader in;
  private CListenThreadListener listener;

  public ReadFromServer(CListenThreadListener listener, InputStreamReader in)
  {
    this.listener = listener;
    this.in = new BufferedReader(in);
    this.start();
  }

  public void run()
  {
    String data;

    // Keep receiving data and posting it back
    try
    {
      for(;;)
      {
        data = in.readLine();
        if(data == null)
        {
          return;
        }
        else
        {
          listener.onDataReceived(data);
        }
      }
    }
    catch (IOException e)
    {
    }
  }
}