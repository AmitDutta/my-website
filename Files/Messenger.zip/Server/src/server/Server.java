package server;

import java.net.*;
import java.io.*;
import java.util.*;


 interface CClientListenListener//1
{
  public void onUserLeave(CClientListenThread c);
  public void onUserAuthenticate(CClientListenThread c, String username);
  public void onUserSendMessage(CClientListenThread c, String to, String message);
  public void onUserSendMessageToAll(CClientListenThread c, String message);
}



class CClientListenThread extends Thread//2
{
  // Constants
  //to parse the commands and messages  need this constants
  //Ref:by Saifur sir
  public static final int CMD_AUTHENTICATE         = 1;//Sign in
  public static final int CMD_USER_JOINED          = 2;
  public static final int CMD_USER_LEFT            = 3;
  public static final int CMD_MESSAGE_RECEIVED     = 4;
  public static final int CMD_ALL_MESSAGE_RECEIVED = 5;
  public static final int CMD_SERVER_SHUTDOWN      = 6; 

 
  public CClientListenListener listener;
  public Socket conn;
  public String username;
  public PrintStream out;
  public BufferedReader in;
  public boolean running;
  public TricksForServer cmd = new TricksForServer();

   public CClientListenThread(CClientListenListener l, Socket s)
  {
    cmd.clientProtocol(false);
    listener = l;
    conn   = s;
    running = true;
    username = "";
    // Create an output stream
    try//to read input
    {
      in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
      out = new PrintStream(conn.getOutputStream());//not printing in Console
    }
    catch(IOException e)
    {
      try
      {
        conn.close();
      }
      catch (IOException e2) {}
    
      return;
    }

    this.start();//Starting taking input
  }

  public void run()
  {
    String buffer = "";

    while(running)
    {
      try
      {
        buffer = in.readLine();
        // Make sure the connection wasn't closed
        if(buffer == null)
        {
          try
          {
            conn.close();
          }
          catch (IOException e3) {}
          conn = null;
          // Call the user left event
          listener.onUserLeave(this);
          return;
        }
        // Process the data received 
        //from client we r getting message 
        //client a separate korleo akane abar korte hobe
        cmd.parseData(buffer);
        switch(cmd.getCommand())
        {
          case CMD_AUTHENTICATE:
          {
            listener.onUserAuthenticate(this, cmd.getUser());
            break;
          }
          case CMD_MESSAGE_RECEIVED:
          {
            listener.onUserSendMessage(this, cmd.getUser(), cmd.getData());
            break;
          }
          case CMD_ALL_MESSAGE_RECEIVED:
          {
            listener.onUserSendMessageToAll(this, cmd.getData());
            break;
          }
        }
      }
      catch (IOException e)
      {
        // There was an error so close the connection
        // to this client
        running = false;
        try
        {
          if(conn != null)
            conn.close();
        }
        catch (IOException e2) {}
        conn = null;
        // Call the user left event
        listener.onUserLeave(this);
      }
    }
  }

  public void sendMessage(String from, String message)
  {
    sendCommand(true, CMD_MESSAGE_RECEIVED, from + "~" + message);
  }

  public void sendMessageToAll(String from, String message)
  {
    sendCommand(true, CMD_ALL_MESSAGE_RECEIVED, from + "~" + message);
  }

  public void sendCommand(boolean valid, int id, String data)
  {
    String command;

    if(valid)
      command = "+";
    else
      command = "-";

    if(id < 10)
      command += "0" + id;
    else
      command += id;

    command += data;

    out.println(command);
      
  }

  public void authenticate(String username)
  {
    this.username = username;
    sendCommand(true, CMD_AUTHENTICATE, "");
  }

  public void reject(String reason)
  {
    sendCommand(false, CMD_AUTHENTICATE, reason);
  }

  public void userJoined(String username)
  {
    sendCommand(true, CMD_USER_JOINED, username);
  }

  public void userLeft(String username)
  {
    sendCommand(true, CMD_USER_LEFT, username);
  }

  public void shutDown()
  {
    
    sendCommand(true, CMD_SERVER_SHUTDOWN, "");
    
    running = false;
    try
    {
      conn.close();
    }
    catch (IOException e) {}
    conn = null;
  }
}



class TricksForServer
{
  
  public static final int CMD_AUTHENTICATE         = 1;
  public static final int CMD_USER_JOINED          = 2;
  public static final int CMD_USER_LEFT            = 3;
  public static final int CMD_MESSAGE_RECEIVED     = 4;
  public static final int CMD_ALL_MESSAGE_RECEIVED = 5;
  public static final int CMD_SERVER_SHUTDOWN      = 6; 

  private boolean bFromServer;
  private boolean bValid;
  private int iCommand;
  private String sUsername;
  private String sData;

  public void clientProtocol(boolean isClient)
  {
    bFromServer = isClient; 
  }

  public void parseData(String sData)
  {
    boolean bGetUser, bGetData;

    bGetUser = false;
    bGetData = false;
    
    
    bValid = false;
    iCommand = 0;
    sUsername = "";
    this.sData = "";
    
    // First get the v
    bValid = sData.substring(0,1).equalsIgnoreCase("-");
    
    // Now get the code
    ////yaaaaaaaaaaaaaaaaaaaaaa i done ittttttttttttt
    
    iCommand = Integer.parseInt(sData.substring(1,3));
/**********************************************
    // Test the command and see what data to extract
    if( iCommand == CMD_AUTHENTICATE)
      bGetUser = true;
      
    if( iCommand == CMD_AUTHENTICATE)
      bGetData = true;
      
    if( iCommand == CMD_USER_JOINED)
      bGetUser = true;
      
    if( iCommand == CMD_USER_LEFT)
      bGetUser = true;
      
    if(iCommand == CMD_MESSAGE_RECEIVED ||
      (iCommand == CMD_ALL_MESSAGE_RECEIVED ))
    {
      bGetUser = true;
      bGetData = true;
    }
    //may be 
    if(iCommand == CMD_ALL_MESSAGE_RECEIVED && ! bFromServer)
      bGetData = true;
  
  // If we only want the user then extract the user details
    if(bGetUser && !bGetData)
    {
      sUsername = sData.substring(3, sData.length());
    }

    // If we only want the data then extract the data
    if(!bGetUser && bGetData)
    {
      this.sData = sData.substring(3, sData.length());
    }
   
    // If we want both the username and data then get them both
    if(bGetUser && bGetData)
    {
      int iPos;
      iPos = sData.indexOf("~");
      if(iPos > 0)
      {
        sUsername = sData.substring(3, iPos);
        this.sData = sData.substring(iPos + 1, sData.length());
      }
    }**********************************/
    
    if( iCommand == CMD_AUTHENTICATE)
      bGetUser = true;
      
      
   /*if(bFromServer && !bValid && iCommand == CMD_AUTHENTICATE)
      bGetData = true;*/
      
      
    if( iCommand == CMD_USER_JOINED)
      bGetUser = true;
    if(bFromServer && bValid && iCommand == CMD_USER_LEFT)
      bGetUser = true;
    if(iCommand == CMD_MESSAGE_RECEIVED ||
      (iCommand == CMD_ALL_MESSAGE_RECEIVED && bFromServer))
    {
      bGetUser = true;
      bGetData = true;
    }
    if(iCommand == CMD_ALL_MESSAGE_RECEIVED && ! bFromServer)
      bGetData = true;
  
  // If we only want the user then extract the user details
    if(bGetUser && !bGetData)
    {
      sUsername = sData.substring(3, sData.length());
      
    }

    // If we only want the data then extract the data
    if(!bGetUser && bGetData)
    {
      this.sData = sData.substring(3, sData.length());
    }
   
    // If we want both the username and data then get them both
    if(bGetUser && bGetData)
    {
      int iPos;
      iPos = sData.indexOf("~");
      if(iPos > 0)
      {
        sUsername = sData.substring(3, iPos);
        this.sData = sData.substring(iPos + 1, sData.length());
      }
    }
 
 }

//these commands are Final
    
 

  public boolean isValid()
  {
    return bValid;
  }

  public int getCommand()
  {
    return iCommand;
  }

  public String getUser()
  {
    return sUsername;
  }

  public String getData()
  {
    return sData;
  }
}


interface CListenListener
{
  public void onListen();
  public void onClose();
  public void onNewConnection(Socket s);
  
}


class CListenThread extends Thread
{
  protected CListenListener listener;

  protected boolean shutdown;
  protected boolean running;
  protected ServerSocket listen_socket;
  protected int port;

  public CListenThread(CListenListener l, int port)
  {
    listener = l;
    shutdown = false;
    running = false;
    this.port = port;

    this.start();
  }

  public void run()
  {
    Socket new_client = null;

   
    while(!shutdown)
    {
      if(running)
      {
      
        try
        {
          new_client = listen_socket.accept();
        }
        catch (IOException e)
        {
          new_client = null;
        }
        if(new_client != null)
        {
       // notun connection klagbe;
          listener.onNewConnection(new_client);
        }
      }
    }
  }
/*
 public CListenThread(CListenListener l, int port)
  {
    listener = l;
    shutdown = false;
    running = false;
    this.port = port;

    this.start();
  }

  public void run()
  {
    

   
    while(!shutdown)
    {
      if(running)
      {
      
        try
        {
          new_client = listen_socket.accept();
        }
        catch (IOException e)
        {
          new_client = null;
        }
        if(new_client != null)
        {
          notun connection klagbe
          listener.onNewConnection(new_client);
        }
      }
    }
  }
 */
  public void shutDown()
  {
    shutdown = true;
    setServerRunState(false);
  }

  public void setServerRunState(boolean running)
  {
    // Only do something if the state has changed
    if(this.running != running)
    {
      if(running)
      {
        // Create the listen socket
        try
        {
          listen_socket = new ServerSocket(port);
        }
        catch(IOException e)
        {
          
        }
       
        try
        {
          listen_socket.setSoTimeout(100);
           listener.onListen();
        }
        catch (IOException e)
        {
          // Raise an error event
//          listener.onListenError(e.getMessage());
        }
      }
      else
      {
        // Close the listen socket
        try
        {
          listen_socket.close();
          listen_socket = null;
          listener.onClose();
        }
        catch (IOException e)
        {
            }
      }
      this.running = running;
    }
  }
}



 interface CMenuListener
{
  public void onServerRunning(boolean enable);
  public void onShutdown();
   public void onShowConnectedUsers();
}
  

//interface CMenuListener finishes here


//class CMenuThread    


//import java.io.*;

class MenuThread extends Thread
{
  public  CMenuListener listener;
  public boolean shutdown;
  public boolean running;
  public boolean anykey;

  public MenuThread(CMenuListener l)
  {
    listener = l;
    shutdown = false;
    
    anykey= false;
    
    running = false;

    this.start();
  }

  public void run()
  {
    String dataIn;
    BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));

    //while(true)
    //shutdown na kora porjonto server run korbe
    //inpiut from keyboard anykey
    
    while(!shutdown)
    {
      if(anykey)
        showPressAnyKey();
      else
        showMenuOptions();
      try
      {
        dataIn = stdIn.readLine();

        if(anykey)
        {
          anykey = false;
        }
        else
        {
          if(dataIn.equals("1"))
            listener.onServerRunning(!running);
        }
      }
      catch (IOException e){ }
    }
  }

  public void anyKeyContinue()
  {
    anykey = true;//jekono  kisu enter korlei hobe
    
  }

  private void showPressAnyKey()
  {
    System.out.println("");
    System.out.print("Press enter to continue");
  }

  private void showMenuOptions()
  {
    int i;
    for (i = 1; i < 20; i++)
      System.out.println("");
    System.out.println("BUET Messenger Server ");
    System.out.println("*****************************");

    if(running)
    {
    	
    	System.out.println("Surver is now running");
    	System.out.println("To close Surver press 1");
    	System.out.println("[1] Stop server");
    	
    }
    
      
    else
    {
    	System.out.println("Surver is not running now. ");
    	System.out.println("To run Server press 1");
    	System.out.println("[1] Start server");
    }
  

}

  public void shutDown()
  {
    shutdown = true;
  }

  //server ar runstate lagbe
  //mane akon run korase ki na 
  public void setServerRunState(boolean running)
  {
  	/*while(!running)
  	 	this.running=false; 
  	 */
    this.running = running;
  }
 }
//ami disi

//class CMenuThread finishes here

//server starts here
public class Server  implements CMenuListener, CListenListener, CClientListenListener
 
{
  public static final int DEFAULT_PORT = 1000;
  private int port;
  private MenuThread menu;
  private CListenThread listen;
  private LinkedList clients = new LinkedList();
  
   public Server(int port)
  {
    if(port == 0)
      this.port = DEFAULT_PORT;//kono port na dile 1000 a connect hobe
    else
      this.port = port;

    // Creating a new text menuthread foe menu
    menu = new MenuThread(this);
    // Create a listen thread
    listen = new CListenThread(this, this.port);
  }

  public void onServerRunning(boolean enable)
  {
    if(!enable)//ata 
    {
      // Inform all clients that the server is stoping
      for(int i = 0; i < clients.size(); i++)
        ((CClientListenThread)clients.get(i)).shutDown();
      clients.clear();//using Linked list classssss

  
    }
   
    listen.setServerRunState(enable);
      
  }

  public void onShutdown()
  {
    // Inform all clients that the server is shutting down
    for(int i = 0; i < clients.size(); i++)
      ((CClientListenThread)clients.get(i)).shutDown(); 
    menu.shutDown();
    listen.shutDown();
   // writeLog("Server shut down");
 //   closeLogFile();
  }

  public void onListen()
  {
    menu.setServerRunState(true);
  }

  public void onClose()
  {
    menu.setServerRunState(false);
  }

  public void onNewConnection(Socket s)
  {
    // Add this connection to the list of users
    clients.add(new CClientListenThread(this, s));
   // writeLog("User connected at address " + s.getRemoteSocketAddress().toString());
  }

   public void onUserLeave(CClientListenThread c)
  {
    // Remove this user
    clients.remove(c);

    // Inform all the other users that this user has left
    if(!c.username.equals(""))
      for(int i = 0; i < clients.size(); i++)
        ((CClientListenThread)clients.get(i)).userLeft(c.username);
        //client listen thread a ace
      }

  public void onUserAuthenticate(CClientListenThread c, String username)
  {
    boolean valid = true;
    // The user has request authentication so make sure the username
    // isn't already taken
    for(int i = 0; i < clients.size(); i++)
      if(((CClientListenThread)clients.get(i)).username.equalsIgnoreCase(username))
        valid = false;

    if(valid)
    {
      c.authenticate(username);
      // Inform all the users that this user has joined
      for(int i = 0; i < clients.size(); i++)
      {
        // Let users who isn't the new one know of the new member
        if(!((CClientListenThread)clients.get(i)).username.equalsIgnoreCase(username))
          ((CClientListenThread)clients.get(i)).userJoined(username);
        // Let the new user know who everyone else is
        c.userJoined(((CClientListenThread)clients.get(i)).username);
      }

    }
    else
    {
      c.reject("Username already taken");
      // Remove the client from the list
      clients.remove(c);
    }
 }//dilum   

  public void onUserSendMessage(CClientListenThread c, String to, String message)
  {
    // Loop through each client until we have the correct user
    for(int i = 0; i < clients.size(); i++)
    {
      if(((CClientListenThread)clients.get(i)).username.equalsIgnoreCase(to))
      {
        ((CClientListenThread)clients.get(i)).sendMessage(c.username, message);
      }
    }
    
    //ai fn ta hoilo private msg ar laiigga
    
  }
  
  

  public void onUserSendMessageToAll(CClientListenThread c, String message)
  {
    // Loop through each client and send the message
    for(int i = 0; i < clients.size(); i++)
      ((CClientListenThread)clients.get(i)).sendMessageToAll(c.username, message);
    //ait sobar kace msg pathai
  }

 

  public void onShowConnectedUsers()
  {
    /*if(clients.size() == 0)
    {
      System.out.println("There are no users connected");
    }
    else
    {*/
      // Loop through each client and output their details
      for(int i = 0; i < clients.size(); i++)
      {
        System.out.println(((CClientListenThread)clients.get(i)).username);
      }
    

    menu.anyKeyContinue();//akane true kora ace

  }
  public static void main (String[] args)
  {
    int port = 0;
    if (args.length == 1)
    {
      try
      {
        port = Integer.parseInt (args[0]);
      }
      catch (NumberFormatException e)
      {
        port = 0;
      }
    }

    new Server (port);
  }
}